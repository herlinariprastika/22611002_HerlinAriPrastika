## LINGKARAN ##
#Keliling Lingkaran
keliling_lingkaran <- function(jari_jari) {
  return(2 * pi * jari_jari)
}

#Luas Lingkaran
luas_lingkaran <- function(jari_jari) {
  return(pi * jari_jari^2)
}

## PERSEGI PANJANG ##
#Keliling Persegi Panjang
keliling_persegi_panjang <- function(panjang, lebar) {
  return(2 * (panjang + lebar))
}

# Luas Persegi Panjang
luas_persegi_panjang <- function(panjang, lebar) {
  return(panjang * lebar)
}

## SEGITIGA ##
#Keliling Segitiga
keliling_segitiga <- function(a, b, c) {
  return(a + b + c)
}

# Luas Segitiga menggunakan rumus Heron
luas_segitiga <- function(a, b, c) {
  s <- (a + b + c) / 2
  return(sqrt(s * (s - a) * (s - b) * (s - c)))
}



